from pathlib import Path

from streamlit.testing.v1 import AppTest

APP = Path(__file__).resolve().parents[1] / "app.py"


def test_notice_chat_crisis_outage_reset(monkeypatch):
    from tests.test_safety import FakeBackend

    monkeypatch.setattr("mannsahara.backend.OllamaBackend", FakeBackend)
    at = AppTest.from_file(APP, default_timeout=15).run()
    assert not at.exception
    assert not at.chat_input
    assert any("synthetic scenarios only" in x.value for x in at.info)
    next(b for b in at.button if b.label == "Begin fictional conversation").click().run()
    assert at.chat_input
    at.chat_input[0].set_value("I feel overwhelmed by exams.").run()
    assert not at.exception
    assert len(at.chat_message) == 2
    at.toggle[0].set_value(True).run()
    at.chat_input[0].set_value("I might hurt myself tonight.").run()
    assert any("Urgent human support" in x.value for x in at.error)
    at.chat_input[0].set_value("Tell me a joke.").run()
    assert at.session_state.chat.escalated
    next(b for b in at.button if b.label == "Clear session / start fresh").click().run()
    assert not at.session_state.chat.escalated
    assert not at.session_state.display and not at.chat_input
    next(b for b in at.button if b.label == "Begin fictional conversation").click().run()
    at.chat_input[0].set_value("I feel lonely.").run()
    assert any("Limited response" in x.value for x in at.warning)
    assert not at.exception


def test_misconfigured_backend_still_displays_crisis(monkeypatch):
    monkeypatch.setenv("MANNSAHARA_OLLAMA_URL", "https://unavailable.invalid")
    at = AppTest.from_file(APP, default_timeout=15).run()
    next(b for b in at.button if b.label == "Begin fictional conversation").click().run()
    at.chat_input[0].set_value("I might hurt myself tonight.").run()
    assert not at.exception
    assert any("Urgent human support" in x.value for x in at.error)
